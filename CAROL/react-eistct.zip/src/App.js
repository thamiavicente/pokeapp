import React from "react";
import "./style.css";
import {Switch, Route, BrowserRouter} from "react-router-dom";
import Pokemons from "./page/Pokemons";

export default function App() {
  return (
    <BrowserRouter>
        <Switch>
          <Route path="/" exact component={Pokemons} />
        </Switch>
    </BrowserRouter>
  );
}
