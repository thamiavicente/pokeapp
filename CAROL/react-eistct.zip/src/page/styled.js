import styled from 'styled-components';

export const HomeContainer = styled.div`
  width: 100%;
  max-width: 991px;
  margin: 0 auto;
`;

export const Title = styled.h1`
  text-align: left;
  font-size: 2.25rem;
  font-family: sans-serif;
  color: #333;
`

export const Content = styled.div`
  width: 100vw;
  display: flex;
  align-items: left;
  justify-content: left;
`;

export const Input = styled.input`
  border: 1px solid #ddd;
  height: 1.5rem;
  padding: 0 .5rem;
  align-items: top;
  border-radius: .25rem 0 0 .25rem;
  &:focus,
  &:active {
    outline: none;
    box-shadow: none;
  }
`;

export const Button = styled.button`
  height: 1.5rem;
  border: 1px solid #000;
  background: #000;
  color: #fff;
  border-radius: 0 .25rem .25rem 0;
  &:focus,
  &:active {
    outline: none;
    box-shadow: none;
  }
`;

export const List = styled.th`
  margin: .5rem 0;
  background: #000;
  color: #fff;
  border-radius: 0 0 0 0;
  padding: .5rem;
  font-size: 1rem;
  font-family: sans-serif;
`;

