import React, { useState } from "react";
import axios from "axios";
import * as S from "./styled";

export default function App(props) {
  const [buscaPokemon, setBuscaPokemon] = useState("");
  const [resultadoPokemon, setResultadoPokemon] = useState([]);

  function handlePesquisa() {
    axios
      .get(`https://pokeapi.co/api/v2/pokemon/${buscaPokemon}`)
      .then(response => {
        setResultadoPokemon(response.data);
        const pokemons = [response.data];
        const pokemonsList = [];
        const imagem = [];
        pokemons.map(results => {
          pokemonsList.push(
            results.id,
            results.name,
            results.types[0].type.name
          );
          imagem.push(results.sprites.front_default);
        });
        console.log(pokemonsList, imagem, pokemons);
        localStorage.setItem("pokemonsList", JSON.stringify(pokemonsList));
      });
  }

  return (
    <S.HomeContainer>
      <title>PokeApp - Desafio We Can Code</title>
      <S.Title>Pokémons</S.Title>

      <S.Content>
        <S.List>Número: {resultadoPokemon.id}</S.List>
        <S.List>Nome: {resultadoPokemon.name}</S.List>
        <S.List>Peso: {resultadoPokemon.weight}</S.List>
        <S.List>Altura: {resultadoPokemon.height}</S.List>
      </S.Content>

      <S.Content>
        <S.Input
          className="Pokémon"
          placeholder="Digite o nome do Pokémon"
          value={buscaPokemon}
          onChange={e => setBuscaPokemon(e.target.value)}
        />
        <S.Button onClick={handlePesquisa}>&#128269;</S.Button>
      </S.Content>
      <S.Content>
        <img
          src={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${
            resultadoPokemon.id
          }.png`}
        />
      </S.Content>
    </S.HomeContainer>
  );
}
